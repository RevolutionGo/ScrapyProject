﻿# Scrapy实战项目合集

## AoiSolas（scrapy采花大盗小爬虫）

> 本爬虫，实现整个妹纸网站爬取，妹纸4000多，图片10W多，合计10G多数据量……[项目详情](http://www.scrapyd.cn/example/176.html)

> ![image](https://github.com/cuanboy/ScrapyProject/blob/master/AoiSolas/gif.gif) 

## scrapyMysql

> Scrapy爬取到的数据如何存入MySQL？如何编写Scrapy组件Piplie本项目会详细告诉你，[项目详情](http://www.scrapyd.cn/jiaocheng/170.html)

## InputMongodb

> 本项目主要演示如何把Scrapy爬到的数据存入MongoDB。[项目详情](http://www.scrapyd.cn/jiaocheng/171.html)

## ImageSpider

> 本项目主要演示如何把Scrapy下载图片。学会了便可以去菜花了 [项目详情](http://www.scrapyd.cn/example/174.html)

## ImagesRename

> scrapy下载图片并重命名而且放入不同目录 [项目详情](http://www.scrapyd.cn/example/175.html)